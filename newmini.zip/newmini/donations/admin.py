from django.contrib import admin
from .models import Restaurant, Supermarket, FoodItem, FoodBankShelter

admin.site.register(Restaurant)
admin.site.register(Supermarket)
admin.site.register(FoodItem)
admin.site.register(FoodBankShelter)