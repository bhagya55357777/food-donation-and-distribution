from django import forms
from .models import FoodItem,Restaurant

class FoodItemForm(forms.ModelForm):
    class Meta:
        model = FoodItem
        fields = ['name', 'quantity', 'pickup_by_date', 'restaurant', 'supermarket']

class RestaurantForm(forms.ModelForm):
    class Meta:
        model = Restaurant
        fields = ['name','address','contact_info']