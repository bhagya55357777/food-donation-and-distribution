from django.shortcuts import render, redirect
from .models import Restaurant, Supermarket, FoodItem, FoodBankShelter
from .forms import FoodItemForm,RestaurantForm

def index(request):
    return render(request, 'index.html')

def restaurant_list(request):
    restaurants = Restaurant.objects.all()
    return render(request, 'restaurant_list.html', {'restaurants': restaurants})

def supermarket_list(request):
    supermarkets = Supermarket.objects.all()
    return render(request, 'supermarket_list.html', {'supermarkets': supermarkets})

def fooditem_list(request):
    fooditems = FoodItem.objects.all()
    return render(request, 'fooditem_list.html', {'fooditems': fooditems})

def foodbankshelter_list(request):
    foodbankshelters = FoodBankShelter.objects.all()
    return render(request, 'foodbankshelter_list.html', {'foodbankshelters': foodbankshelters})

def fooditem_create(request):
    if request.method == 'POST':
        form = FoodItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('fooditem_list')
    else:
        form = FoodItemForm()
    return render(request, 'fooditem_form.html', {'form': form})

def restaurant_create(request):
    if request.method == 'POST':
        form = RestaurantForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('restaurant_list')
    else:
        form = RestaurantForm()
    return render(request, 'restaurant_form.html', {'form': form})