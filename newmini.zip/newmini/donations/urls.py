from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('restaurants/', views.restaurant_list, name='restaurant_list'),
    path('supermarkets/', views.supermarket_list, name='supermarket_list'),
    path('fooditems/', views.fooditem_list, name='fooditem_list'),
    path('foodbankshelters/', views.foodbankshelter_list, name='foodbankshelter_list'),
    path('fooditem/add/', views.fooditem_create, name='fooditem_create'),
    path('restaurant/add/', views.restaurant_create, name='restaurant_create'),
]